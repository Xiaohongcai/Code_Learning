import os

# 设置一个变量，该变量为指定保存的路径,windows系统下的D盘，test目录
dir_name = 'D:\\Dutch Learning\\'
# 判断D盘下是否存在test目录，如果不存在该目录，则创建test目录
if not os.path.exists(dir_name):
    os.mkdir(dir_name)
content = '文本测试，文本测试，文本测试'
# 在D盘的test目录下创建一个file.txt的文本，写入变量content
fb = open(dir_name + 'test book.xlsx',mode='w',encoding='utf-8')
fb.write(content)
print('创建完成...')

