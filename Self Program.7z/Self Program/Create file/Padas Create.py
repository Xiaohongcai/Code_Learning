

import pandas as pd
df = pd.DataFrame()
df.to_excel('D:\\Learning Dutch\\a.xlsx')
