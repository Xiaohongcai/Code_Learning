
from openpyxl import Workbook, load_workbook
import sys 

ad =  'c:\\Users\\dcai\\OneDrive - ASML\\Dutch_Learning\\' 
name = 'inburgeringsexamen A2'
wb = load_workbook(ad + name + '.xlsx')
wb.create_sheet('Lesson 12')
wb.save(ad + name + '.xlsx')


#wb.sheetnames

"""
for j in [11,111,121]:
    wb.remove(wb["Lesson " + str(j)])
"""

"""
for i in range(1, 15):
    wb.create_sheet(title = "Lesson " + str(i))
"""

#----------------------------------

#wb.create_sheet('111')
#wb.sheetnames
#ws1 = wb.create_sheet("Lesson 1")

#for i in [3,5,6,8]:
   # del wb['Sheet' + str(i)]



#ws.title = 'Lesson one'
#ws = wb.active

#---------------------------------------
""" ws1 = wb.create_sheet("Mysheet") # insert at the end (default)
    # or
    >>> ws2 = wb.create_sheet("Mysheet", 0) # insert at first position
    # or
    >>> ws3 = wb.create_sheet("Mysheet", -1) # insert at the penultimate position
"""





