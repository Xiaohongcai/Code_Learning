#This is operate the template of Working PPT

from pptx import Presentation
from PIL import Image
import os

import function.slide_editor as editPPT
import function.Working_Path as Working_Path
import copy
import six

#--------------------------------------------------Test path---------------------------------------------------#
# 1.0: blank, 1.1: table(reference), 1.2: no_figure_text, 1.3: 1_figure, 1.4: 2_Figure, 1.5: 3_Figure, 1.6: 4_Figure
# ad_Temp = r'C:\Users\dcai\OneDrive - ASML\Working Related\Template\\'
# name_Temp = 'ASML PPT Templete'
ad_Desti = r'C:\Users\dcai\OneDrive - ASML\Working Related\Current works\PPT_Making\\'
name_Desti = 'test'

File_to_operate = Working_Path.Temp_PPT
current_ppt = Presentation( File_to_operate)
#--------------------------------------------insert slide and Layout list--------------------------------------------#
# 1.0: Chapter, 1.1: table(reference), 1.2: no_figure_text, 1.3: 1_figure, 1.4: 2_Figure, 1.5: 3_Figure, 1.6: 4_Figure

layout = current_ppt.slide_masters[1].slide_layouts[6]
new_insert = current_ppt.slides.add_slide(layout)
Move_to_Top = editPPT.move_slide(current_ppt, new_insert, 1)


#current_ppt = Presentation( ad_Desti + name_Desti + '.pptx')
#name = 'ASML PPT Templete'

#--------------------------------------------Copy slide--------------------------------------------#
# for i in range(4):
#   copied_slide = editPPT.duplicate_slide(current_ppt, 3,4)


#--------------------------------------------list the placeholders--------------------------------------------#
# slide = current_ppt.slides[2]
# for shape in slide.placeholders:
#   print('%d %s' % (shape.placeholder_format.idx, shape.name))

#--------------------------------------------Title page_Change contect of placeholders--------------------------------------------#
#slide = current_ppt.slides[0]
# slide.placeholders[10].text = 'Dongbin'         # name of operaor
# slide.placeholders[11].text = 'Date'            #Date
# slide.placeholders[12].text = 'Title'          #Title
# slide.placeholders[14].text = 'Design Engineer'    # Function of operater

#--------------------------------------------Reference_Slide_Operation--------------------------------------------#
# for i in range(2):
#   copied_slide = editPPT.duplicate_slide(current_ppt, 3,4)

# slide = current_ppt.slides[2]
# # PH_Title = slide.placeholders[0].text = 'Reference'
# # PH_Subtitle = slide.placeholders[14].text = 'After W etching'
# for i in range(1,9,1):
#   Table_10 = slide.placeholders[15].table.cell(i,0).text = 'RD' + str(i)

#--------------------------------------------0_Figure_Slide_Operation--------------------------------------------#
# for i in range(2):
#   copied_slide = editPPT.duplicate_slide(current_ppt, 3,4)

# slide = current_ppt.slides[3]
# PH_Title = slide.placeholders[0].text = 'I love PPT'
# PH_Subtitle = slide.placeholders[14].text = 'After W etching'
# PH_Text_Main = slide.placeholders[13].text = 'As Figure 1 show,'

#--------------------------------------------1_Figure_Slide_Operation--------------------------------------------#
# slide = current_ppt.slides[4]
# PH_Title = new_insert.placeholders[0].text = 'I love PPT'
# PH_Subtitle = slide.placeholders[14].text = 'After W etching'
# PH_Text_Main = slide.placeholders[21].text = 'As Figure 1 show,'
# PH_Picture_1 = slide.placeholders[16].insert_picture(r'C:\Users\dcai\OneDrive - ASML\Working Related\Current works\CR works\KE\Laser writer\LER\03.jpg')
# PH_Figure_label_1 = slide.placeholders[20].text = 'Figure 1: SEM of sidewall'

#--------------------------------------------2_Figure_Slide_Operation--------------------------------------------#
# slide = current_ppt.slides[5]
# PH_Title = slide.placeholders[0].text = 'I love PPT'
# PH_Subtitle = slide.placeholders[14].text = 'After W etching'
# PH_Text_Main = slide.placeholders[17].text = 'As Figure 1 show,'
# PH_Text_Main = slide.placeholders[18].text = 'As Figure 2 show,'
# PH_Picture_1 = slide.placeholders[15].insert_picture(r'C:\Users\dcai\OneDrive - ASML\Working Related\Current works\CR works\KE\Laser writer\LER\03.jpg')
# PH_Picture_2 = slide.placeholders[16].insert_picture(r'C:\Users\dcai\OneDrive - ASML\Working Related\Current works\CR works\KE\Laser writer\LER\01.jpg')
# PH_Figure_label_1 = slide.placeholders[19].text = 'Figure 1: SEM of sidewall'
# PH_Figure_label_2 = slide.placeholders[20].text = 'Figure 2: SEM of sidewall'

#--------------------------------------------3_Figure_Slide_Operation--------------------------------------------#
# slide = current_ppt.slides[6]
# PH_Title = slide.placeholders[0].text = 'I love PPT'
# PH_Subtitle = slide.placeholders[14].text = 'After W etching'
# PH_Text_Main = slide.placeholders[18].text = 'As Figure 1 show,'
# PH_Picture_1 = slide.placeholders[16].insert_picture(r'C:\Users\dcai\OneDrive - ASML\Working Related\Current works\CR works\KE\Laser writer\LER\03.jpg')
# PH_Picture_2 = slide.placeholders[17].insert_picture(r'C:\Users\dcai\OneDrive - ASML\Working Related\Current works\CR works\KE\Laser writer\LER\01.jpg')
# PH_Picture_3 = slide.placeholders[15].insert_picture(r'C:\Users\dcai\OneDrive - ASML\Working Related\Current works\CR works\KE\Laser writer\LER\02.jpg')
# PH_Figure_label_1 = slide.placeholders[19].text = 'Figure 1: SEM of sidewall'
# PH_Figure_label_2 = slide.placeholders[20].text = 'Figure 2: SEM of sidewall'
# PH_Figure_label_3 = slide.placeholders[21].text = 'Figure 3: SEM of sidewall'

#--------------------------------------------4_Figure_Slide_Operation--------------------------------------------#
# slide = current_ppt.slides[7]
# PH_Title = slide.placeholders[0].text = 'I love PPT'
# PH_Subtitle = slide.placeholders[28].text = 'After W etching'
# PH_Text_Main 1 = slide.placeholders[26].text = 'As Figure 1 show,'
# PH_Text_Main 2= slide.placeholders[27].text = 'As Figure 2 show,'
# PH_Picture_1 = slide.placeholders[15].insert_picture(r'C:\Users\dcai\OneDrive - ASML\Working Related\Current works\CR works\KE\Laser writer\LER\03.jpg')
# PH_Picture_2 = slide.placeholders[20].insert_picture(r'C:\Users\dcai\OneDrive - ASML\Working Related\Current works\CR works\KE\Laser writer\LER\01.jpg')
# PH_Picture_3 = slide.placeholders[22].insert_picture(r'C:\Users\dcai\OneDrive - ASML\Working Related\Current works\CR works\KE\Laser writer\LER\02.jpg')
# PH_Picture_4 = slide.placeholders[24].insert_picture(r'C:\Users\dcai\OneDrive - ASML\Working Related\Current works\CR works\KE\Laser writer\LER\02.jpg')
# PH_Figure_label_1 = slide.placeholders[19].text = 'Figure 1: SEM of sidewall'
# PH_Figure_label_2 = slide.placeholders[21].text = 'Figure 2: SEM of sidewall'
# PH_Figure_label_3 = slide.placeholders[23].text = 'Figure 3: SEM of sidewall'
# PH_Figure_label_4 = slide.placeholders[25].text = 'Figure 3: SEM of sidewall'




#--------------------------------------------Give title together--------------------------------------------#
# page_num_start = 4
# num_add_page = 5
# for i in range ( page_num_start - 1,page_num_start +num_add_page -1, 1 ):
#   current_ppt.slides[i].placeholders[0].text = str(i-3)+'_Figure_Slide'         # Title of the slide.placeholders




current_ppt.save(ad_Desti + name_Desti + '.pptx')
#current_ppt.save(ad_Temp + name_Temp + '.pptx')
