#--------------------------------------------------Test path---------------------------------------------------#
Temp_PPT = r'C:/Users/dcai/OneDrive - ASML/Working Related/Template/' + 'ASML PPT Templete' + '.pptx'
Desti_PPT = r'C:/Users/dcai/OneDrive - ASML/Working Related/Current works/PPT_Making/' + 'test' + '.pptx'


#--------------------------------------------------KE_AA_Weekly_updat---------------------------------------------------#
KE_AA_Weekly_update = r'C:/Users/dcai/OneDrive - ASML/Working Related/Current works/PPT_Making/' + 'Temp' + '.pptx'
KE_AA_Weekly_update_copy = r'C:/Dongbin Cai/Working Related copy/' + 'Status update BSA, KE and AA' + '.pptx'
    

