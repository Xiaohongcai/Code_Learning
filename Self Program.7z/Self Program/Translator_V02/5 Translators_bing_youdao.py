#-------------------------------------------------------------------#
from openpyxl import Workbook, load_workbook
import sys 
from turtle import end_fill
#-------------------------------------------------------------------#
import Dictionaries.deepl.api as Deepl_translation
import Dictionaries.Google as Google_translation
from Dictionaries.MultiTrans import*
import  Dictionaries.Youdao as Youdao_translation
from Dictionaries.google_V02 import google_translator 


#-------------------------------------------------------------------#

#-------------------------------------------------------------------#

#-------------------------------------------------------------------#
class Translation():
        [Input_contant, result_deepl, result_google, result_google_cn, result_bing, result_youdao, mode_choose,i,j] = ['','','','','','','',1,1]
        
        def MC():

                if Translation.mode_choose == '1':
                        Translation.mode1()
                        Translation.mode_choose = 0
                elif Translation.mode_choose == '2':
                        Translation.mode2()
                        Translation.mode_choose = 0
                elif Translation.mode_choose == '3':
                        Translation.mode3()
                        Translation.mode_choose = 0
                elif Translation.mode_choose == '4':
                        Translation.mode4()
                        Translation.mode_choose = 0
                elif Translation.mode_choose == '25':
                        Translation.mode25()
                        Translation.mode_choose = 0  
                elif Translation.mode_choose == '5':
                        Translation.mode5()
                        Translation.mode_choose = 0  
#-------------------------------------------------------------------#
          

        def To_Excel():     

                ad =  'c:\\Users\\dcai\\OneDrive - ASML\\Dutch_Learning\\' 
               # ad = 'C:\Dongbin Cai\Dutch_Learning\\'
                name = 'inburgeringsexamen A2'
                wb = load_workbook(ad + name + '.xlsx')
                ws  = wb["Lesson 12"]
               
                start = ws.cell(row=Translation.i, column=1).value
                while start is not None:
                        Translation.i=Translation.i+1
                        start = ws.cell(row=Translation.i+1, column=1).value
                                              
                ws.cell(row = Translation.i, column = Translation.j).value =  Translation.Input_contant
                ws.cell(row = Translation.i, column = Translation.j+1).value = Translation.result_deepl
                ws.cell(row = Translation.i, column = Translation.j+2).value = Translation.result_google
                ws.cell(row = Translation.i, column = Translation.j+3).value = Translation.result_google_cn
                ws.cell(row = Translation.i, column = Translation.j+4).value = Translation.result_youdao
                        
                wb.save(ad + name + '.xlsx')
                


#----------------------------mode1 translate by Deepl ---------------------------------------#
       
        def mode1():
                while True:
                        Translation.Input_contant = input('input the text that you want to translate:')
                        if  Translation.Input_contant == "\\end":
                                break
                        else:
                                Translation.result_deepl = Deepl_translation.translate(source_language=SL, target_language=TL, text=Translation.Input_contant)
                                Translation.result_google = Google_translation.translate(Translation.Input_contant, TL, SL)
                                print ( Translation.result_deepl )
                                Translation.To_Excel()
    


#----------------------------mode2 translate by google ---------------------------------------#

        def mode2():
                while True:
                        Translation.Input_contant = input('input the text that you want to translate:')
                        if  Translation.Input_contant == "\\end":
                                break
                        else:
                                #Translation.result_deepl = Deepl_translation.translate(source_language=SL, target_language=TL, text=Translation.Input_contant)
                                Translation.result_google = google_translator().translate(Translation.Input_contant, lang_tgt=TL, lang_src=SL)
                                Translation.result_google_cn = google_translator().translate(Translation.result_google, lang_tgt='zh')
                                #Translation.result_google = Google_translation.translate(Translation.Input_contant, TL, SL)
                                print ( Translation.result_google )
                                print (Translation.result_google_cn)
                                Translation.To_Excel()
                                

#--------------------------mode3 translate by google + Deepl-----------------------------------------#
        def mode3():
                while True:        
                        Translation.Input_contant = input('input the text that you want to translate:')
                        if  Translation.Input_contant == "\\end":
                                break
                        else:
                                Translation.result_deepl = Deepl_translation.translate(source_language=SL, target_language=TL, text=Translation.Input_contant)
                                Translation.result_google = Google_translation.translate(Translation.Input_contant, TL, SL)
                                print ('Google:\n', Translation.result_google + '\n' +'Deepl:\n'+  Translation.result_deepl )
                                Translation.To_Excel()
                               
#--------------------------mode4 translate by bing-----------------------------------------#                  
        def mode4():
                while True:
                        Translation.Input_contant = input('input the text that you want to translate:')
                        if  Translation.Input_contant == "\\end":
                                break
                        else:
                                @loguru.logger.catch
                                def test1():
                                        Translation.result_bing = bing( Translation.Input_contant, to_language=TL)
                                        print ('bing:\n', bing( Translation.Input_contant, to_language=TL) )
                                        # print('youdao:\n', youdao((query_text), to_language='zh'))
                                        Translation.To_Excel()
                                if __name__ == "__main__":
                                        test1()     

#----------------------------mode5 translate by google ---------------------------------------#

        def mode5():
                while True:
                        Translation.Input_contant = input('input the text that you want to translate:')
                        if  Translation.Input_contant == "\\end":
                                break
                        else:
                                #Translation.result_deepl = Deepl_translation.translate(source_language=SL, target_language=TL, text=Translation.Input_contant)
                                print("youdao:")
                                youdao_json = Youdao_translation.fetch(Youdao_translation.sanitize_arg(Translation.Input_contant))
                                Translation.result_youdao = Youdao_translation.parse((youdao_json))
                                print("<----------------------------------------------->")
                                print(Translation.result_youdao)
                                
                                #Translation.To_Excel()      
                                
                                
                                
#----------------------------mode25 translate by google ---------------------------------------#

        def mode25():
                while True:
                        Translation.Input_contant = input('input the text that you want to translate:')
                        if  Translation.Input_contant == "\\end":
                                break
                        else:
                                #Translation.result_deepl = Deepl_translation.translate(source_language=SL, target_language=TL, text=Translation.Input_contant)
                                Translation.result_google = Google_translation.translate(Translation.Input_contant, TL, SL)
                                print ( "google:\n " + Translation.result_google)
                                print("youdao:")
                                youdao_json = Youdao_translation.fetch(Youdao_translation.sanitize_arg(Translation.result_google))
                                Translation.result_youdao = Youdao_translation.parse((youdao_json))
                                print("<----------------------------------------------->")
                                print(Translation.result_youdao)
                                Translation.To_Excel()      
                                     
    
    



#-------------------------#  main # -------------------------#
while True:
        SL = input('Source language:')
        if SL == '\end': 
                break
        TL = input('target language:')
        if TL == '\end':
                break
        b = 1
        while True:
                while Translation.mode_choose not in ['1','2','3','4','5','25','\end']:
                        Translation.mode_choose = input('type the mode you want to use(1=Deepl,2=Google,3=Google+Deepl,4=bing, 5 = youdao, 25=google+youdao):')
                if Translation.mode_choose == '\end':
                        break
                Translation.MC()
                [Input_contant, result_deepl, result_google, result_google_cn, result_bing, result_youdao, mode_choose,i,j] = ['','','','','','','',1,1]

                        
#-------------------------------------------------------------#





                

