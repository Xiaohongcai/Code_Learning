from openpyxl import Workbook, load_workbook
import sys 
sys.path.append('d:\Learning_code\Deepl_02') 
from turtle import end_fill
import deepl


#-----------------------------------
ad = 'C:\\Users\\caido\\OneDrive\\Dutch Learning\\'
name = 'inburgeringsexamen A2'
wb = load_workbook(ad + name + '.xlsx')
#wb.create_sheet('')
ws  = wb["Lesson 11"]
#-----------------------------------


var = 1
i = 1
j = 1
SL = input()
TL = input()

while var ==1:
    if ws.cell(row=i, column=1).value is None:
        text = input()
        if  text == "end":
             break
        else:
             result = deepl.translate(source_language=SL, target_language=TL, text=text)
        print (result)
        a = ws.cell(row = i, column = j)
        a.value = text
        b = ws.cell(row = i, column = j+1)
        b.value = result
        i=i+1
    else:
         i=i+1





wb.save(ad + name + '.xlsx')




 