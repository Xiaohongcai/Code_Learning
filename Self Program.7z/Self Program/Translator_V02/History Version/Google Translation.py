
from openpyxl import Workbook, load_workbook
import sys 
sys.path.append('d:\Learning_code\Google Translator\mtranslate') 
import core

#-----------------------------------
ad = 'C:\\Users\\caido\\OneDrive\\Dutch Learning\\'
name = 'inburgeringsexamen A2'
wb = load_workbook(ad + name + '.xlsx')
ws  = wb["Lesson 1"]
#-----------------------------------


var = 1
i = 1
j = 1
while var ==1:
    if ws.cell(row=i, column=1).value is None:
        text = input()
        if  text == "end":
             break
        else:
             result = core.translate(text, "en", "nl")
        print (result)
        a = ws.cell(row = i, column = j)
        a.value = text
        b = ws.cell(row = i, column = j+1)
        b.value = result
        i=i+1
    else:
         i=i+1





wb.save(ad + name + '.xlsx')

