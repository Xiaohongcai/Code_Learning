#-------------------------------------------------------------------#
from openpyxl import Workbook, load_workbook
import sys 
from turtle import end_fill
#-------------------------------------------------------------------#
sys.path.append('D:\Learning_code\Other Program\Translators\Deepl') 
import deepl
#-------------------------------------------------------------------#
sys.path.append('D:\Learning_code\Other Program\Translators\Google\mtranslate') 
import core
#-------------------------------------------------------------------#
from goto import with_goto
from goto import goto, label
#-------------------------------------------------------------------#

#-------------------------------------------------------------------#
class Translation():
        [Input_contant, result_deepl, result_google,mode_choose,i,j] = [0,0,0,0,1,1]
        
        def MC():

                if Translation.mode_choose == '1':
                        Translation.mode1()
                        Translation.mode_choose = 0
                elif Translation.mode_choose == '2':
                        Translation.mode2()
                        Translation.mode_choose = 0
                elif Translation.mode_choose == '3':
                        Translation.mode3()
                        Translation.mode_choose = 0

#-------------------------------------------------------------------#
        
        def To_Excel():     

                ad = 'C:\\Users\\caido\\OneDrive\\Dutch Learning\\'
                name = 'inburgeringsexamen A2'
                wb = load_workbook(ad + name + '.xlsx')
                #wb.create_sheet('test')
                #ws  = wb["Lesson 11"]
                ws  = wb["Lesson 1"]
               
                start = ws.cell(row=Translation.i, column=1).value
                while start is not None:
                        Translation.i=Translation.i+1
                        start = ws.cell(row=Translation.i+1, column=1).value
                                              
                ws.cell(row = Translation.i, column = Translation.j).value =  Translation.Input_contant
                ws.cell(row = Translation.i, column = Translation.j+1).value = Translation.result_deepl
                ws.cell(row = Translation.i, column = Translation.j+2).value = Translation.result_google 
                        
                wb.save(ad + name + '.xlsx')
                

#-------------------------------------------------------------------#
        def mode3():
                var = 1
                while var ==1:
                        
                        Translation.Input_contant = input('input the text that you want to translate:')
                        if  Translation.Input_contant == "\\end":
                                break
                        else:
                                Translation.result_deepl = deepl.translate(source_language=SL, target_language=TL, text=Translation.Input_contant)
                                Translation.result_google = core.translate(Translation.Input_contant, TL, SL)
                                print ( Translation.result_google + '\n' +  Translation.result_deepl )
                                Translation.To_Excel()
                               
#-------------------------------------------------------------------#

#-------------------------------------------------------------------#

        def mode2():
                var = 1
                while var ==1:
                       
                        Translation.Input_contant = input('input the text that you want to translate:')
                        if  Translation.Input_contant == "\\end":
                                break
                        else:
                                Translation.result_deepl = deepl.translate(source_language=SL, target_language=TL, text=Translation.Input_contant)
                                Translation.result_google = core.translate(Translation.Input_contant, "en", "nl")
                                print ( Translation.result_google )
                                Translation.To_Excel()

        def mode1():
                var = 1
                while var ==1:
                       
                        Translation.Input_contant = input('input the text that you want to translate:')
                        if  Translation.Input_contant == "\\end":
                                break
                        else:
                                Translation.result_deepl = deepl.translate(source_language=SL, target_language=TL, text=Translation.Input_contant)
                                Translation.result_google = core.translate(Translation.Input_contant, "en", "nl")
                                print ( Translation.result_deepl )
                                Translation.To_Excel()
    



#-------------------------#  main # -------------------------#

SL = input('Source language:')
TL = input('target language:')
b = 1
while True:
        while Translation.mode_choose not in ['1','2','3','\end']:
                Translation.mode_choose = input('type the mode you want to use(1=Deepl,2=Google,3=Google+Deepl,):')
        if Translation.mode_choose == '\end':
                break
        Translation.MC()

                        
#-------------------------------------------------------------#





                

