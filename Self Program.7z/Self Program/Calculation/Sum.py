n = int(input("Enter n: "))
nums = []
for _ in range(n):
    nums.append(int(input()))
print(sum(nums))